/**
 * Les POJO des donn�es sportives.
 **/
package donnees;